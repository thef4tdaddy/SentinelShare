
# @check-spelling-bot Report
## :red_circle: Please review
### See the [:open_file_folder: files](https://github.com/thef4tdaddy/SentinelShare/pull/257/files/) view, the [:scroll:action log](https://github.com/thef4tdaddy/SentinelShare/actions/runs/20606460200/job/59183144578#step:4:1),  or [:memo: job summary](https://github.com/thef4tdaddy/SentinelShare/actions/runs/20606460200/attempts/1#summary-59183144578) for details.

[:x: Errors](https://docs.check-spelling.dev/Event-descriptions) | Count
-|-
[:x: ignored-expect-variant](https://docs.check-spelling.dev/Event-descriptions#ignored-expect-variant) | 1

See [:x: Event descriptions](https://docs.check-spelling.dev/Event-descriptions) for more information.

<details><summary>These words are not needed and should be removed
</summary>ccabf 
</details><p></p>

<details><summary>Available :books: dictionaries could cover words (expected and unrecognized) not in the :blue_book: dictionary</summary>

This includes both **expected items** (292) from .github/actions/spelling/expect.txt and **unrecognized words** (0)

Dictionary | Entries | Covers | Uniquely
-|-|-|-
[cspell:django/dict/django.txt](https://raw.githubusercontent.com/check-spelling/cspell-dicts/v20230509/dictionaries/django/dict/django.txt)|393|2|2|
[cspell:shell/dict/shell-all-words.txt](https://raw.githubusercontent.com/check-spelling/cspell-dicts/v20230509/dictionaries/shell/dict/shell-all-words.txt)|113|1|1|
[cspell:mnemonics/src/mnemonics.txt](https://raw.githubusercontent.com/check-spelling/cspell-dicts/v20230509/dictionaries/mnemonics/src/mnemonics.txt)|800|1|1|

Consider adding them (in `.github/workflows/spell-check.yml`) in `jobs:`/`spelling:` for `uses: check-spelling/check-spelling@v0.0.24` in its `with` to `extra_dictionaries`:
``` yml
          cspell:django/dict/django.txt
          cspell:shell/dict/shell-all-words.txt
          cspell:mnemonics/src/mnemonics.txt
```
To stop checking additional dictionaries, add (in `.github/workflows/spell-check.yml`) for `uses: check-spelling/check-spelling@v0.0.24` in its `with`:
``` yml
check_extra_dictionaries: ''
```

</details>
